import numpy as np

data = np.loadtxt("data0.csv",delimiter=",")

print(data)