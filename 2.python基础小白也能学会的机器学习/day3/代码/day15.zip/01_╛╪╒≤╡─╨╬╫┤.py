import numpy as np

data = np.array(
    [
        [
            [1, 2, 3],
            [2, 3, 4]
        ],
        [
            [4, 5, 6],
            [5, 6, 7]
        ]
    ])

print(data.shape)
